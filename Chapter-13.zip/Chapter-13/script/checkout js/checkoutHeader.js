import { cart , updateCartQuantity} from "../../data/itemCart.js";
import { products } from "../../data/products.js";

function renderCheckoutHeader(){
    updateCartQuantity()
    return updateCartQuantity();
}
console.log(updateCartQuantity())
